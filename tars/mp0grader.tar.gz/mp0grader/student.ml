(* CS421 - Spring 2011
 * MP0
 *
 * Please keep in mind that there may be more than one
 * way to solve a problem.  You will want to change how a number of these start.
 *)

open Mp0common

(* Problem 1 *)
let a = 0;;  (* You will want to change this. *)

(* Problem 2 *)
let s = "Something else you will want to change";;

(* Problem 3 *)
let add_a n =
  raise(Failure "Function not implemented yet.")

(* Problem 4 *)
let greetings name =
  raise(Failure "Function not implemented yet.")

(* Problem 5 *)
let greetstring name =
  raise(Failure "Function not implemented yet.")

(* Problem 6 *)
let sign n =
  raise(Failure "Function not implemented yet.")
