(* CS421 - Spring 2013
 * MP1
 *)

(* Problem 1 *)
let pair_to_list (x, y) = failwith "not implemented"

(* Problem 2 *)
let dist ((x0,y0), (x1,y1)) = failwith "not implemented"

(* Problem 3 *)
let sort_first_two l = failwith "not implemented"

(* Problem 4 *)
let rec concat_odd l = failwith "not implemented"

(* Problem 5 *)
let rec is_sorted l = failwith "not implemented"

(* Problem 6 *)
let rec group_ascending lis = failwith "not implemented"

(* Problem 7 *)
let rec split_list lis = failwith "not implemented"

(* Problem 8 *)
let rec merge l1 l2 = failwith "not implemented"

(* Problem 9 *)
let rec mergesort lis = failwith "not implemented"

